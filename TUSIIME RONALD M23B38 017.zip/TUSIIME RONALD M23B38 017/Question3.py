# QuickSort
def quick_sort(arr):
    if len(arr) <= 1:
        return arr
    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]
    return quick_sort(left) + middle + quick_sort(right)

#BubbleSort
def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]

unsorted_list = [14, 27, 8, -42, 11, 35, -9, 56, 23]

#QuickSort
sorted_list_quick_sort = quick_sort(unsorted_list)
print("Sorted List using QuickSort:", sorted_list_quick_sort)
 # QuickSort Complexity Class is log linear

#BubbleSort
sorted_list_bubble_sort = bubble_sort(unsorted_list)
print("Sorted List using BubbleSort:", sorted_list_bubble_sort)
# BubbleSort Complexity Class is quadratic







