class studentQueue:
    def __init__(self):
        self.queue = []

    def enqueue(self, student):
        self.queue.append(student)

    def dequeue(self):
        if len(self.queue) < 1:
            return None
        return self.queue.pop(0)

    def is_empty(self):
        return self.queue == []

    def get_size(self):
        return len(self.queue)
    


students = studentQueue()

print("Is queue empty", students.is_empty()) 

students.enqueue("agaba")
students.enqueue("marth")
students.enqueue("Carol")

print("Is quueue empty.", students.is_empty()) 
print("Current size :", students.get_size()) 
print("Next student :", students.dequeue()) 
print("Current size:", students.get_size())     



